--
-- PostgreSQL database cluster dump
--

\restrict FhN4PiE2uoOuPmjw65PaOdPsWz0rmQwTUax8cN9eyc2iXNP6eFhllBqcymtJAz7

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE patrick;
ALTER ROLE patrick WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;

--
-- User Configurations
--








\unrestrict FhN4PiE2uoOuPmjw65PaOdPsWz0rmQwTUax8cN9eyc2iXNP6eFhllBqcymtJAz7

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict jvXONVNWMJhlZ5a4XgY1NywHNg9lt5KEwWhwLuQWB92D1t0U6pfvjAgmTi3TVgd

-- Dumped from database version 16.11 (Homebrew)
-- Dumped by pg_dump version 16.11 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict jvXONVNWMJhlZ5a4XgY1NywHNg9lt5KEwWhwLuQWB92D1t0U6pfvjAgmTi3TVgd

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict elm44kjGborcnFgTLmFjlndpYBdUBRelzQzhdHzEckhiLe5b8AOa1eFasSVaCKl

-- Dumped from database version 16.11 (Homebrew)
-- Dumped by pg_dump version 16.11 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict elm44kjGborcnFgTLmFjlndpYBdUBRelzQzhdHzEckhiLe5b8AOa1eFasSVaCKl

--
-- PostgreSQL database cluster dump complete
--

